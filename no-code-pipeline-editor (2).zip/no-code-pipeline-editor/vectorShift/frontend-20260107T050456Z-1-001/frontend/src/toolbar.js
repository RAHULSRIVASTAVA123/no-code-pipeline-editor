// import React from "react";
// import { useStore } from "./store";

// export const PipelineToolbar = () => {
//   const addNode = useStore((state) => state.addNode);
//   const getNodeID = useStore((state) => state.getNodeID);

//   const add = (type) => {
//     const id = getNodeID(type);
//     addNode({
//       id,
//       type,
//       position: { x: 250, y: 150 },
//       data: { id, nodeType: type },
//     });
//   };

//   const btn = {
//     padding: "6px 12px",
//     cursor: "pointer",
//   };

//   return (
//     <div style={{ display: "flex", gap: "8px", padding: "10px", flexWrap: "wrap" }}>
//       {/* Existing */}
//       <button style={btn} onClick={() => add("input")}>Input</button>
//       <button style={btn} onClick={() => add("llm")}>LLM</button>
//       <button style={btn} onClick={() => add("output")}>Output</button>
//       <button style={btn} onClick={() => add("text")}>Text</button>

//       {/* New nodes (STEP 3 requirement) */}
//       <button style={btn} onClick={() => add("number")}>Number</button>
//       <button style={btn} onClick={() => add("delay")}>Delay</button>
//       <button style={btn} onClick={() => add("merge")}>Merge</button>
//       <button style={btn} onClick={() => add("logger")}>Logger</button>
//       <button style={btn} onClick={() => add("condition")}>Condition</button>
//     </div>
//   );
// };

// import React from "react";
// import { useStore } from "./store";

// export const PipelineToolbar = () => {
//   const addNode = useStore((state) => state.addNode);
//   const getNodeID = useStore((state) => state.getNodeID);

//   const add = (type) => {
//     const id = getNodeID(type);
//     addNode({
//       id,
//       type,
//       position: { x: 250, y: 150 },
//       data: { id, nodeType: type },
//     });
//   };

//   // ✅ ONLY styling updated
//   const btn = {
//     padding: "7px 16px",
//     cursor: "pointer",
//     borderRadius: "999px",
//     border: "1px solid #d1d5db",
//     background: "#ffffff",
//     color: "#111827",
//     fontSize: "13px",
//     fontWeight: 500,
//     transition: "all 0.15s ease",
//   };

//   const onHoverIn = (e) => {
//     e.currentTarget.style.background = "#f3f4f6";
//     e.currentTarget.style.borderColor = "#9ca3af";
//     e.currentTarget.style.transform = "translateY(-1px)";
//     e.currentTarget.style.boxShadow = "0 4px 10px rgba(0,0,0,0.08)";
//   };

//   const onHoverOut = (e) => {
//     e.currentTarget.style.background = "#ffffff";
//     e.currentTarget.style.borderColor = "#d1d5db";
//     e.currentTarget.style.transform = "translateY(0)";
//     e.currentTarget.style.boxShadow = "none";
//   };

//   return (
//     <div style={{ display: "flex", gap: "8px", padding: "10px", flexWrap: "wrap" }}>
//       {/* Existing */}
//       <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("input")}>Input</button>
//       <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("llm")}>LLM</button>
//       <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("output")}>Output</button>
//       <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("text")}>Text</button>

//       {/* New nodes */}
//       <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("number")}>Number</button>
//       <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("delay")}>Delay</button>
//       <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("merge")}>Merge</button>
//       <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("logger")}>Logger</button>
//       <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("condition")}>Condition</button>
//     </div>
//   );
// };


import React from "react";
import { useStore } from "./store";

export const PipelineToolbar = () => {
  const addNode = useStore((state) => state.addNode);
  const getNodeID = useStore((state) => state.getNodeID);

  const add = (type) => {
    const id = getNodeID(type);
    addNode({
      id,
      type,
      position: { x: 250, y: 150 },
      data: { id, nodeType: type },
    });
  };

  /* ---------- Button base style ---------- */
  const btn = {
    padding: "6px 14px",
    cursor: "pointer",
    borderRadius: "999px",
    border: "1px solid #cbd5e1",
    background: "#ffffff",
    color: "#0f172a",
    fontSize: "13px",
    fontWeight: 500,
    transition: "all 0.2s ease",
    whiteSpace: "nowrap",
  };

  /* ---------- Hover effects ---------- */
  const onHoverIn = (e) => {
    e.currentTarget.style.background = "#f1f5f9";
    e.currentTarget.style.borderColor = "#94a3b8";
    e.currentTarget.style.boxShadow =
      "0 4px 12px rgba(0,0,0,0.06)";
  };

  const onHoverOut = (e) => {
    e.currentTarget.style.background = "#ffffff";
    e.currentTarget.style.borderColor = "#cbd5e1";
    e.currentTarget.style.boxShadow = "none";
  };

  return (
    <div
      style={{
        display: "flex",
        gap: "10px",
        padding: "10px 14px",
        alignItems: "center",
        flexWrap: "wrap",
        background: "#f8fafc",
        borderBottom: "1px solid #e5e7eb",
      }}
    >
      <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("input")}>Input</button>
      <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("llm")}>LLM</button>
      <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("output")}>Output</button>
      <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("text")}>Text</button>

      <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("number")}>Number</button>
      <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("delay")}>Delay</button>
      <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("merge")}>Merge</button>
      <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("logger")}>Logger</button>
      <button style={btn} onMouseEnter={onHoverIn} onMouseLeave={onHoverOut} onClick={() => add("condition")}>Condition</button>
    </div>
  );
};
