// import React from "react";
// import { useStore } from "./store";

// export const SubmitButton = () => {
//   const nodes = useStore((state) => state.nodes);
//   const edges = useStore((state) => state.edges);

//   const handleSubmit = async () => {
//     try {
//       const response = await fetch("http://localhost:8000/pipelines/parse", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           nodes,
//           edges,
//         }),
//       });

//       const data = await response.json();

//       alert(
//         `Pipeline Summary\n\n` +
//         `Nodes: ${data.num_nodes}\n` +
//         `Edges: ${data.num_edges}\n` +
//         `Is DAG: ${data.is_dag ? "Yes" : "No"}`
//       );
//     } catch (error) {
//       alert("Error submitting pipeline");
//       console.error(error);
//     }
//   };

//   return (
//     <div style={{ textAlign: "center", marginTop: "12px" }}>
//       <button onClick={handleSubmit}>Submit</button>
//     </div>
//   );
// };


import React, { useState } from "react";
import { useStore } from "./store";

export const SubmitButton = () => {
  const nodes = useStore((state) => state.nodes);
  const edges = useStore((state) => state.edges);

  const [result, setResult] = useState(null);

  const handleSubmit = async () => {
    try {
      const response = await fetch("http://localhost:8000/pipelines/parse", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ nodes, edges }),
      });

      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error(error);
      alert("Error submitting pipeline");
    }
  };

  return (
    <>
      {/* Submit Button */}
      <div
        style={{
          textAlign: "center",
          marginTop: "40px",
          marginBottom: "24px",
        }}
      >
        <button
          style={submitBtn}
          onMouseEnter={hoverIn}
          onMouseLeave={hoverOut}
          onClick={handleSubmit}
        >
          Submit
        </button>
      </div>

      {/* Modal */}
      {result && (
        <div style={overlayStyle}>
          <div style={modalStyle}>
            <h3 style={{ marginBottom: "12px" }}>Pipeline Summary</h3>

            <div style={rowStyle}>
              <strong>Nodes:</strong> {result.num_nodes}
            </div>
            <div style={rowStyle}>
              <strong>Edges:</strong> {result.num_edges}
            </div>
            <div style={rowStyle}>
              <strong>Is DAG:</strong>{" "}
              {result.is_dag ? "Yes ✅" : "No ❌"}
            </div>

            <button
              style={closeBtn}
              onClick={() => setResult(null)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};

/* ------------------ Button Styles ------------------ */

const submitBtn = {
  padding: "10px 28px",
  borderRadius: "999px",
  border: "1px solid #d1d5db",
  background: "#ffffff",       // ✅ white
  color: "#111827",
  fontSize: "14px",
  fontWeight: 600,
  cursor: "pointer",
  transition: "all 0.15s ease",
};

const hoverIn = (e) => {
  e.currentTarget.style.background = "#f3f4f6";
  e.currentTarget.style.transform = "translateY(-1px)";
  e.currentTarget.style.boxShadow =
    "0 4px 10px rgba(0,0,0,0.08)";
};

const hoverOut = (e) => {
  e.currentTarget.style.background = "#ffffff";
  e.currentTarget.style.transform = "translateY(0)";
  e.currentTarget.style.boxShadow = "none";
};

/* ------------------ Modal Styles (unchanged) ------------------ */

const overlayStyle = {
  position: "fixed",
  top: 0,
  left: 0,
  width: "100vw",
  height: "100vh",
  background: "rgba(0,0,0,0.4)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: 999,
};

const modalStyle = {
  background: "#fff",
  padding: "20px",
  borderRadius: "12px",
  width: "300px",
  boxShadow: "0 10px 30px rgba(0,0,0,0.2)",
  textAlign: "center",
};

const rowStyle = {
  marginBottom: "8px",
  fontSize: "14px",
};

const closeBtn = {
  marginTop: "14px",
  padding: "6px 14px",
  borderRadius: "8px",
  border: "none",
  cursor: "pointer",
  background: "#2563eb",
  color: "#fff",
};
