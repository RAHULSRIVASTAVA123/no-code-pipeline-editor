// import React from "react";
// import { Handle, Position } from "reactflow";

// const BaseNode = ({ title, inputs = [], outputs = [], children }) => {
//   return (
//     <div
//       style={{
//         border: "1px solid #ddd",
//         borderRadius: "8px",
//         padding: "8px",
//         background: "#fff",
//         width: "200px",
//       }}
//     >
//       <div style={{ fontWeight: "bold", marginBottom: "6px" }}>
//         {title}
//       </div>

//       {/* Input Handles */}
//       {inputs.map((input, index) => (
//         <Handle
//           key={input.id}
//           type="target"
//           position={Position.Left}
//           id={input.id}
//           style={{ top: 40 + index * 20 }}
//         />
//       ))}

//       {/* Output Handles */}
//       {outputs.map((output, index) => (
//         <Handle
//           key={output.id}
//           type="source"
//           position={Position.Right}
//           id={output.id}
//           style={{ top: 40 + index * 20 }}
//         />
//       ))}

//       <div>{children}</div>
//     </div>
//   );
// };

// export default BaseNode;

import React from "react";
import { Handle, Position } from "reactflow";

const BaseNode = ({ title, inputs = [], outputs = [], children }) => {
  return (
    <div
      style={{
        border: "1px solid #e5e7eb",
        borderRadius: "12px",
        padding: "12px",
        background: "#ffffff",
        width: "220px",
        boxShadow: "0 6px 16px rgba(0, 0, 0, 0.08)",
        position: "relative",
        fontFamily: "Inter, system-ui, sans-serif",
      }}
    >
      {/* Title */}
      <div
        style={{
          fontWeight: 600,
          fontSize: "14px",
          marginBottom: "10px",
          color: "#111827",
        }}
      >
        {title}
      </div>

      {/* Input Handles */}
      {inputs.map((input, index) => (
        <Handle
          key={input.id}
          type="target"
          position={Position.Left}
          id={input.id}
          style={{
            top: 48 + index * 24,
            background: "#2563eb",
            width: "10px",
            height: "10px",
            borderRadius: "50%",
          }}
        />
      ))}

      {/* Output Handles */}
      {outputs.map((output, index) => (
        <Handle
          key={output.id}
          type="source"
          position={Position.Right}
          id={output.id}
          style={{
            top: 48 + index * 24,
            background: "#16a34a",
            width: "10px",
            height: "10px",
            borderRadius: "50%",
          }}
        />
      ))}

      {/* Content */}
      <div
        style={{
          fontSize: "13px",
          color: "#374151",
        }}
      >
        {children}
      </div>
    </div>
  );
};

export default BaseNode;

