// import React, { useState, useEffect } from "react";
// import BaseNode from "./BaseNode";

// const VARIABLE_REGEX = /{{\s*([a-zA-Z_$][a-zA-Z0-9_$]*)\s*}}/g;

// export default function TextNode() {
//   const [text, setText] = useState("");
//   const [variables, setVariables] = useState([]);

//   useEffect(() => {
//     const matches = [...text.matchAll(VARIABLE_REGEX)];
//     const vars = [...new Set(matches.map((m) => m[1]))];
//     setVariables(vars);
//   }, [text]);

//   const inputs = variables.map((v) => ({ id: v }));

//   return (
//     <BaseNode
//       title="Text"
//       inputs={inputs}
//       outputs={[{ id: "text" }]}
//     >
//       <textarea
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//         placeholder="Enter text (use {{variable}})"
//         style={{
//           width: "100%",
//           minHeight: "60px",
//           resize: "none",
//         }}
//       />
//     </BaseNode>
//   );
// }


// import React, { useState, useEffect, useRef } from "react";
// import BaseNode from "./BaseNode";

// const VARIABLE_REGEX = /{{\s*([a-zA-Z_$][a-zA-Z0-9_$]*)\s*}}/g;

// export default function TextNode() {
//   const [text, setText] = useState("");
//   const [variables, setVariables] = useState([]);
//   const textareaRef = useRef(null);

//   /* ---------------- Detect variables ---------------- */
//   useEffect(() => {
//     const matches = [...text.matchAll(VARIABLE_REGEX)];
//     const vars = [...new Set(matches.map((m) => m[1]))];
//     setVariables(vars);
//   }, [text]);

//   /* ---------------- Auto resize textarea ---------------- */
//   useEffect(() => {
//     if (!textareaRef.current) return;
//     textareaRef.current.style.height = "auto";
//     textareaRef.current.style.height =
//       textareaRef.current.scrollHeight + "px";
//   }, [text]);

//   const inputs = variables.map((v) => ({ id: v }));

//   return (
//     <BaseNode
//       title="Text"
//       inputs={inputs}
//       outputs={[{ id: "text" }]}
//     >
//       {/* IMPORTANT: wrapper allows handles to receive pointer events */}
//       <div style={{ pointerEvents: "none" }}>
//         <textarea
//           ref={textareaRef}
//           value={text}
//           onChange={(e) => setText(e.target.value)}
//           placeholder="Enter text (use {{variable}})"
//           style={{
//             pointerEvents: "auto",   // allow typing
//             width: "100%",
//             resize: "none",
//             overflow: "hidden",
//             minHeight: "60px",
//             padding: "6px",
//             fontSize: "13px",
//             borderRadius: "6px",
//             border: "1px solid #d1d5db",
//             fontFamily: "inherit",
//           }}
//         />
//       </div>
//     </BaseNode>
//   );
// }


import React, { useState, useEffect, useRef, useMemo } from "react";
import BaseNode from "./BaseNode";
import { useStore } from "../store";

// supports {{out}}, {{out.a}}, {{out.a.b}}
const VARIABLE_REGEX = /{{\s*([a-zA-Z_$][a-zA-Z0-9_$.]*)\s*}}/g;

// helper to resolve object paths like out.a.b
const resolvePath = (obj, path) => {
  if (!obj || !path) return undefined;
  return path.split(".").reduce((acc, key) => {
    if (acc && acc[key] !== undefined) return acc[key];
    return undefined;
  }, obj);
};

export default function TextNode({ id, data }) {
  const nodes = useStore((state) => state.nodes);
  const edges = useStore((state) => state.edges);
  const updateNodeField = useStore((state) => state.updateNodeField);

  const [text, setText] = useState(data?.text ?? "");
  const textareaRef = useRef(null);

  /* -------- Detect variables -------- */
  const variables = useMemo(() => {
    const matches = [...text.matchAll(VARIABLE_REGEX)];
    return [...new Set(matches.map((m) => m[1]))];
  }, [text]);

  /* -------- Auto resize textarea -------- */
  useEffect(() => {
    if (!textareaRef.current) return;
    textareaRef.current.style.height = "auto";
    textareaRef.current.style.height =
      textareaRef.current.scrollHeight + "px";
  }, [text]);

  /* -------- Resolve variables -------- */
  const resolvedText = useMemo(() => {
    let result = text;

    variables.forEach((variable) => {
      // split {{out.a.b}} → handle=out, path=a.b
      const [handle, ...pathParts] = variable.split(".");
      const path = pathParts.join(".");

      const edge = edges.find(
        (e) => e.target === id && e.targetHandle === handle
      );
      if (!edge) return;

      const sourceNode = nodes.find((n) => n.id === edge.source);
      const baseValue = sourceNode?.data?.value;

      const finalValue =
        path ? resolvePath(baseValue, path) : baseValue;

      const replacement =
        finalValue === undefined
          ? ""
          : typeof finalValue === "object"
          ? JSON.stringify(finalValue)
          : String(finalValue);

      result = result.replaceAll(`{{${variable}}}`, replacement);
    });

    return result;
  }, [text, variables, edges, nodes, id]);

  /* -------- Commit output safely -------- */
  useEffect(() => {
    if (data?.value !== resolvedText) {
      updateNodeField(id, "value", resolvedText);
    }
    if (data?.text !== text) {
      updateNodeField(id, "text", text);
    }
  }, [resolvedText, text, data?.value, data?.text, id, updateNodeField]);

  // inputs are the FIRST part of variables (handles)
  const inputs = [...new Set(variables.map((v) => v.split(".")[0]))].map(
    (v) => ({ id: v })
  );

  return (
    <BaseNode
      title="Text"
      inputs={inputs}
      outputs={[{ id: "text" }]}
    >
      <textarea
        ref={textareaRef}
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter text (use {{out.a}})"
        style={{
          width: "100%",
          resize: "none",
          overflow: "hidden",
          minHeight: "60px",
          padding: "6px",
          fontSize: "13px",
          borderRadius: "6px",
          border: "1px solid #d1d5db",
          fontFamily: "inherit",
        }}
      />
    </BaseNode>
  );
}

