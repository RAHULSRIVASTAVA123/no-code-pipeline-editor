// import React from "react";
// import BaseNode from "./BaseNode";

// export default function InputNode() {
//   return (
//     <BaseNode title="Input" outputs={[{ id: "output" }]}>
//       <div>Input Value</div>
//     </BaseNode>
//   );
// }

import React from "react";
import BaseNode from "./BaseNode";
import { useStore } from "../store";

export default function InputNode({ id, data }) {
  const updateNodeField = useStore((state) => state.updateNodeField);

  return (
    <BaseNode
      title="Input"
      outputs={[{ id: "output" }]}
    >
      <textarea
        value={data.value ?? ""}
        onChange={(e) =>
          updateNodeField(id, "value", e.target.value)
        }
        placeholder="Enter input text"
        rows={3}
        style={{
          width: "100%",
          resize: "none",
          padding: "6px 8px",
          borderRadius: "6px",
          border: "1px solid #cbd5e1",
          outline: "none",
          fontSize: "13px",
        }}
      />
    </BaseNode>
  );
}
