// import React from "react";
// import BaseNode from "./BaseNode";

// export default function MergeNode() {
//   return (
//     <BaseNode
//       title="logger"
//       inputs={[{ id: "a" }, { id: "b" }]}
//       outputs={[{ id: "out" }]}
//     >
//       <div>Merge Inputs</div>
//     </BaseNode>
//   );
// }


import React, { useMemo, useEffect } from "react";
import BaseNode from "./BaseNode";
import { useStore } from "../store";

export default function LoggerNode({ id, data }) {
  const nodes = useStore((state) => state.nodes);
  const edges = useStore((state) => state.edges);
  const updateNodeField = useStore((state) => state.updateNodeField);

  // 🔹 Read incoming value
  const inputValue = useMemo(() => {
    const edge = edges.find((e) => e.target === id);
    if (!edge) return undefined;

    const sourceNode = nodes.find((n) => n.id === edge.source);
    return sourceNode?.data?.value;
  }, [edges, nodes, id]);

  // 🔹 Pass-through (logger should not modify data)
  useEffect(() => {
    if (data?.value !== inputValue) {
      updateNodeField(id, "value", inputValue);
    }
  }, [inputValue, data?.value, id, updateNodeField]);

  const displayValue =
    typeof inputValue === "object"
      ? JSON.stringify(inputValue, null, 2)
      : String(inputValue ?? "");

  return (
    <BaseNode
      title="Logger"
      inputs={[{ id: "in" }]}
      outputs={[{ id: "out" }]}
    >
      <pre
        style={{
          fontSize: 12,
          maxHeight: 120,
          overflow: "auto",
          background: "#f8fafc",
          padding: "6px",
          borderRadius: "6px",
          whiteSpace: "pre-wrap",
          wordBreak: "break-word",
        }}
      >
        {displayValue || "Waiting for input…"}
      </pre>
    </BaseNode>
  );
}
