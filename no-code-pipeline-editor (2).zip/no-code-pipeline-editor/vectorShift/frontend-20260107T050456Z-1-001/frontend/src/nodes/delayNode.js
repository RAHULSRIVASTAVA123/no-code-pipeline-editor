// import React from "react";
// import BaseNode from "./BaseNode";

// export default function DelayNode() {
//   return (
//     <BaseNode
//       title="Delay"
//       inputs={[{ id: "in" }]}
//       outputs={[{ id: "out" }]}
//     >
//       <div>Delay</div>
//     </BaseNode>
//   );
// }

import React, { useEffect, useMemo, useState } from "react";
import BaseNode from "./BaseNode";
import { useStore } from "../store";

export default function DelayNode({ id, data }) {
  const nodes = useStore((state) => state.nodes);
  const edges = useStore((state) => state.edges);
  const updateNodeField = useStore((state) => state.updateNodeField);

  const delayMs = data.delay ?? 1000;
  const [localOutput, setLocalOutput] = useState(null);

  const inputValue = useMemo(() => {
    const edge = edges.find((e) => e.target === id);
    if (!edge) return null;

    const source = nodes.find((n) => n.id === edge.source);
    return source?.data?.value ?? null;
  }, [edges, nodes, id]);

  useEffect(() => {
    if (inputValue === null) return;

    const timer = setTimeout(() => {
      // prevent infinite loop
      if (
        JSON.stringify(data?.value) !== JSON.stringify(inputValue)
      ) {
        setLocalOutput(inputValue);
        updateNodeField(id, "value", inputValue);
      }
    }, delayMs);

    return () => clearTimeout(timer);
  }, [inputValue, delayMs, id, updateNodeField, data?.value]);

  return (
    <BaseNode
      title="Delay"
      inputs={[{ id: "in" }]}
      outputs={[{ id: "out" }]}
    >
      <div style={{ marginBottom: 6 }}>
        <label style={{ fontSize: 12 }}>Delay (ms)</label>
        <input
          type="number"
          value={delayMs}
          onChange={(e) =>
            updateNodeField(id, "delay", Number(e.target.value))
          }
          style={{ width: "100%" }}
        />
      </div>

      <div style={{ fontSize: 12 }}>
        {localOutput !== null ? "Delayed ✔️" : "Waiting…"}
      </div>
    </BaseNode>
  );
}

