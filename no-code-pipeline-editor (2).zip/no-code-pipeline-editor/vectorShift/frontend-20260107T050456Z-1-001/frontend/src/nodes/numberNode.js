// import React from "react";
// import BaseNode from "./BaseNode";

// export default function NumberNode() {
//   return (
//     <BaseNode
//       title="Number"
//       outputs={[{ id: "value" }]}
//     >
//       <div>42</div>
//     </BaseNode>
//   );
// }


import React from "react";
import BaseNode from "./BaseNode";
import { useStore } from "../store";

export default function NumberNode({ id, data }) {
  const updateNodeField = useStore((state) => state.updateNodeField);

  return (
    <BaseNode
      title="Number"
      outputs={[{ id: "value" }]}
    >
      <input
        type="number"
        value={data.value ?? ""}
        onChange={(e) =>
          updateNodeField(id, "value", Number(e.target.value))
        }
        style={{
          width: "100%",
          padding: "6px 8px",
          borderRadius: "6px",
          border: "1px solid #cbd5e1",
          outline: "none",
        }}
        placeholder="Enter number"
      />
    </BaseNode>
  );
}

