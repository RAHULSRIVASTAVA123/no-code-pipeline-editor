// import React from "react";
// import BaseNode from "./BaseNode";

// export default function LLMNode() {
//   return (
//     <BaseNode
//       title="LLM"
//       inputs={[{ id: "prompt" }]}
//       outputs={[{ id: "response" }]}
//     >
//       <div>LLM Processing</div>
//     </BaseNode>
//   );
// }

import React, { useEffect, useMemo, useState } from "react";
import BaseNode from "./BaseNode";
import { useStore } from "../store";

export default function LLMNode({ id, data }) {
  const nodes = useStore((state) => state.nodes);
  const edges = useStore((state) => state.edges);
  const updateNodeField = useStore((state) => state.updateNodeField);

  const [loading, setLoading] = useState(false);

  // 🔹 Read prompt input
  const prompt = useMemo(() => {
    const edge = edges.find((e) => e.target === id);
    if (!edge) return "";

    const sourceNode = nodes.find((n) => n.id === edge.source);
    return sourceNode?.data?.value ?? "";
  }, [edges, nodes, id]);

  // 🔹 Simulate LLM call
  useEffect(() => {
    if (!prompt || typeof prompt !== "string") return;

    let cancelled = false;
    setLoading(true);

    const timeout = setTimeout(() => {
      if (cancelled) return;

      const response = `LLM Response: ${prompt}`;

      updateNodeField(id, "value", response);
      setLoading(false);
    }, 1500);

    return () => {
      cancelled = true;
      clearTimeout(timeout);
    };
  }, [prompt, id, updateNodeField]);

  return (
    <BaseNode
      title="LLM"
      inputs={[{ id: "prompt" }]}
      outputs={[{ id: "response" }]}
    >
      <div
        style={{
          fontSize: 13,
          color: loading ? "#64748b" : "#0f172a",
        }}
      >
        {loading
          ? "Thinking..."
          : data?.value
          ? "Response ready ✔️"
          : "Waiting for prompt"}
      </div>
    </BaseNode>
  );
}

