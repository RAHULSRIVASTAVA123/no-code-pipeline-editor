// import React from "react";
// import BaseNode from "./BaseNode";

// export default function OutputNode() {
//   return (
//     <BaseNode
//       title="Output"
//       inputs={[{ id: "input" }]}
//     >
//       <div>Final Output</div>
//     </BaseNode>
//   );
// }


// import React, { useMemo } from "react";
// import BaseNode from "./BaseNode";
// import { useStore } from "../store";

// export default function OutputNode({ id }) {
//   const nodes = useStore((state) => state.nodes);
//   const edges = useStore((state) => state.edges);

//   // Find incoming edge
//   const inputValue = useMemo(() => {
//     const incomingEdge = edges.find((e) => e.target === id);
//     if (!incomingEdge) return "";

//     const sourceNode = nodes.find(
//       (n) => n.id === incomingEdge.source
//     );

//     return sourceNode?.data?.value ?? "";
//   }, [edges, nodes, id]);

//   return (
//     <BaseNode
//       title="Output"
//       inputs={[{ id: "input" }]}
//     >
//       <div
//         style={{
//           minHeight: "24px",
//           padding: "4px 6px",
//           fontWeight: 500,
//           color: "#0f172a",
//         }}
//       >
//         {inputValue !== "" ? inputValue : "Final Output"}
//       </div>
//     </BaseNode>
//   );
// }


// import React, { useMemo } from "react";
// import BaseNode from "./BaseNode";
// import { useStore } from "../store";

// export default function OutputNode({ id }) {
//   const nodes = useStore((state) => state.nodes);
//   const edges = useStore((state) => state.edges);

//   const inputValue = useMemo(() => {
//     const edge = edges.find((e) => e.target === id);
//     if (!edge) return null;

//     const sourceNode = nodes.find(
//       (n) => n.id === edge.source
//     );

//     return sourceNode?.data?.value ?? null;
//   }, [edges, nodes, id]);

//   return (
//     <BaseNode title="Output" inputs={[{ id: "input" }]}>
//       <pre
//         style={{
//           minHeight: 24,
//           padding: "6px",
//           fontSize: 12,
//           background: "#f8fafc",
//           borderRadius: 6,
//           whiteSpace: "pre-wrap",
//         }}
//       >
//         {inputValue !== null
//           ? JSON.stringify(inputValue, null, 2)
//           : "Final Output"}
//       </pre>
//     </BaseNode>
//   );
// }

// import React, { useMemo } from "react";
// import BaseNode from "./BaseNode";
// import { useStore } from "../store";

// export default function OutputNode({ id }) {
//   const nodes = useStore((state) => state.nodes);
//   const edges = useStore((state) => state.edges);

//   const inputValue = useMemo(() => {
//     const edge = edges.find((e) => e.target === id);
//     if (!edge) return null;

//     const sourceNode = nodes.find((n) => n.id === edge.source);
//     return sourceNode?.data?.value ?? null;
//   }, [edges, nodes, id]);

//   const renderValue = (value) => {
//     if (value === null || value === undefined) return "Final Output";

//     if (typeof value === "object") {
//       return JSON.stringify(value, null, 2);
//     }

//     return String(value);
//   };

//   return (
//     <BaseNode title="Output" inputs={[{ id: "input" }]}>
//       <pre
//         style={{
//           minHeight: 24,
//           padding: "6px",
//           fontSize: 13,
//           whiteSpace: "pre-wrap",
//           wordBreak: "break-word",
//         }}
//       >
//         {renderValue(inputValue)}
//       </pre>
//     </BaseNode>
//   );
// }


import React, { useMemo } from "react";
import BaseNode from "./BaseNode";
import { useStore } from "../store";

export default function OutputNode({ id }) {
  const nodes = useStore((state) => state.nodes);
  const edges = useStore((state) => state.edges);

  const inputValue = useMemo(() => {
    const edge = edges.find((e) => e.target === id);
    if (!edge) return null;

    const sourceNode = nodes.find((n) => n.id === edge.source);
    return sourceNode?.data?.value ?? null;
  }, [edges, nodes, id]);

  if (inputValue?.error) {
    return (
      <BaseNode title="Output" inputs={[{ id: "input" }]}>
        <div
          style={{
            color: "#b91c1c",
            fontWeight: 600,
            padding: "6px",
          }}
        >
          ❌ {inputValue.message || "Wrong input"}
        </div>
      </BaseNode>
    );
  }

  return (
    <BaseNode title="Output" inputs={[{ id: "input" }]}>
      <pre
        style={{
          padding: "6px",
          fontSize: 13,
          whiteSpace: "pre-wrap",
        }}
      >
        {typeof inputValue === "object"
          ? JSON.stringify(inputValue, null, 2)
          : String(inputValue ?? "Final Output")}
      </pre>
    </BaseNode>
  );
}
