import React, { useMemo, useEffect, useState } from "react";
import BaseNode from "./BaseNode";
import { useStore } from "../store";

export default function ConditionNode({ id, data }) {
  const nodes = useStore((state) => state.nodes);
  const edges = useStore((state) => state.edges);
  const updateNodeField = useStore((state) => state.updateNodeField);

  const [expression, setExpression] = useState(
    data?.expression ?? "value < 10"
  );

  // get input value
  const inputValue = useMemo(() => {
    const edge = edges.find((e) => e.target === id);
    if (!edge) return undefined;

    const sourceNode = nodes.find((n) => n.id === edge.source);
    return sourceNode?.data?.value;
  }, [edges, nodes, id]);

  // evaluate condition
  const conditionResult = useMemo(() => {
    if (inputValue === undefined) return null;

    try {

      const fn = new Function("value", `return (${expression});`);
      return Boolean(fn(inputValue));
    } catch {
      return false;
    }
  }, [expression, inputValue]);

  
  useEffect(() => {
    if (conditionResult === null) return;

    if (conditionResult) {
      updateNodeField(id, "value", inputValue);
    } else {
      updateNodeField(id, "value", {
        error: true,
        message: "Wrong input",
      });
    }
  }, [conditionResult, inputValue, id, updateNodeField]);

  return (
    <BaseNode
      title="Condition"
      inputs={[{ id: "value" }]}
      outputs={[{ id: "true" }, { id: "false" }]}
    >
      <input
        type="text"
        value={expression}
        onChange={(e) => setExpression(e.target.value)}
        placeholder="e.g. value < 10"
        style={{
          width: "100%",
          padding: "6px",
          fontSize: 13,
          borderRadius: 6,
          border: "1px solid #d1d5db",
        }}
      />

      <div style={{ fontSize: 12, marginTop: 6 }}>
        Result:{" "}
        {conditionResult === null
          ? "—"
          : conditionResult
          ? "TRUE ✔️"
          : "FALSE ❌"}
      </div>
    </BaseNode>
  );
}

