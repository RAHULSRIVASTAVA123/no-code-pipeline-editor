// import React from "react";
// import BaseNode from "./BaseNode";

// export default function MergeNode() {
//   return (
//     <BaseNode
//       title="Merge"
//       inputs={[{ id: "a" }, { id: "b" }]}
//       outputs={[{ id: "out" }]}
//     >
//       <div>Merge Inputs</div>
//     </BaseNode>
//   );
// }

// import React, { useMemo } from "react";
// import BaseNode from "./BaseNode";
// import { useStore } from "../store";

// export default function MergeNode({ id }) {
//   const nodes = useStore((state) => state.nodes);
//   const edges = useStore((state) => state.edges);

//   // Collect all incoming values
//   const mergedValue = useMemo(() => {
//     const incomingEdges = edges.filter((e) => e.target === id);

//     const result = {};

//     incomingEdges.forEach((edge) => {
//       const sourceNode = nodes.find(
//         (n) => n.id === edge.source
//       );

//       if (sourceNode?.data?.value !== undefined) {
//         // Use handle id (a, b) as key if available
//         const key = edge.targetHandle || sourceNode.type;
//         result[key] = sourceNode.data.value;
//       }
//     });

//     return result;
//   }, [edges, nodes, id]);

//   return (
//     <BaseNode
//       title="Merge"
//       inputs={[{ id: "a" }, { id: "b" }]}
//       outputs={[{ id: "out" }]}
//     >
//       <div
//         style={{
//           fontSize: "12px",
//           color: "#334155",
//           wordBreak: "break-word",
//         }}
//       >
//         {Object.keys(mergedValue).length > 0
//           ? JSON.stringify(mergedValue, null, 2)
//           : "Merge Inputs"}
//       </div>
//     </BaseNode>
//   );
// }

import React, { useMemo, useEffect } from "react";
import BaseNode from "./BaseNode";
import { useStore } from "../store";

export default function MergeNode({ id, data }) {
  const nodes = useStore((state) => state.nodes);
  const edges = useStore((state) => state.edges);
  const updateNodeField = useStore((state) => state.updateNodeField);

  const mergedValue = useMemo(() => {
    const incomingEdges = edges.filter((e) => e.target === id);
    const result = {};

    incomingEdges.forEach((edge) => {
      const sourceNode = nodes.find((n) => n.id === edge.source);
      if (sourceNode?.data?.value !== undefined) {
        const key = edge.targetHandle || sourceNode.type;
        result[key] = sourceNode.data.value;
      }
    });

    return result;
  }, [edges, nodes, id]);

  // ✅ PREVENT INFINITE LOOP
  useEffect(() => {
    const prev = data?.value;

    // shallow compare
    const changed =
      JSON.stringify(prev) !== JSON.stringify(mergedValue);

    if (changed) {
      updateNodeField(id, "value", mergedValue);
    }
  }, [mergedValue, data?.value, id, updateNodeField]);

  return (
    <BaseNode
      title="Merge"
      inputs={[{ id: "a" }, { id: "b" }]}
      outputs={[{ id: "out" }]}
    >
      <pre style={{ fontSize: "12px" }}>
        {Object.keys(mergedValue).length
          ? JSON.stringify(mergedValue, null, 2)
          : "Merge Inputs"}
      </pre>
    </BaseNode>
  );
}
