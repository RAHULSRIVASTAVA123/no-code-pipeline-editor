# Visual Pipeline Builder

A simple visual pipeline editor built with **React** and **React Flow**.  
It allows creating and connecting nodes to build data-processing workflows.

---

## Features

- Drag-and-drop node-based editor
- Clean and minimal UI
- Multiple node types:
  - Input
  - Text
  - Number
  - Merge
  - Delay
  - Condition
  - Logger
  - LLM (mocked)
  - Output
- Supports dynamic data flow between nodes
- Conditional routing and validation
- Easy to extend with new nodes

---

## Tech Stack

- React
- React Flow
- Zustand (state management)
- JavaScript

---

## Getting Started

### Install dependencies

npm install
