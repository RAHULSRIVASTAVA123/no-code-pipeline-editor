# from fastapi import FastAPI
# from fastapi.middleware.cors import CORSMiddleware
# from typing import Dict

# app = FastAPI()

# # ✅ CORS FIX
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["http://localhost:3000"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# @app.post("/pipelines/parse")
# def parse_pipeline(payload: Dict):
#     nodes = payload.get("nodes", [])
#     edges = payload.get("edges", [])

#     num_nodes = len(nodes)
#     num_edges = len(edges)

#     # Build graph
#     graph = {}
#     indegree = {}

#     for node in nodes:
#         graph[node["id"]] = []
#         indegree[node["id"]] = 0

#     for edge in edges:
#         src = edge["source"]
#         tgt = edge["target"]
#         graph[src].append(tgt)
#         indegree[tgt] += 1

#     # Kahn's algorithm for DAG
#     queue = [n for n in indegree if indegree[n] == 0]
#     visited = 0

#     while queue:
#         curr = queue.pop(0)
#         visited += 1
#         for nei in graph[curr]:
#             indegree[nei] -= 1
#             if indegree[nei] == 0:
#                 queue.append(nei)

#     is_dag = visited == num_nodes

#     return {
#         "num_nodes": num_nodes,
#         "num_edges": num_edges,
#         "is_dag": is_dag,
#     }

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict
import json

app = FastAPI()

# ✅ CORS FIX
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/pipelines/parse")
def parse_pipeline(payload: Dict):
    # 🔍 DEBUG: Print full payload
    print("\n================ PIPELINE RECEIVED ================\n")
    print(json.dumps(payload, indent=2))
    print("\n===================================================\n")

    nodes = payload.get("nodes", [])
    edges = payload.get("edges", [])

    # 🔍 DEBUG: Print nodes
    print(f"Total Nodes: {len(nodes)}")
    for node in nodes:
        print(f"Node ID: {node.get('id')}, Type: {node.get('type')}")

    # 🔍 DEBUG: Print edges
    print(f"\nTotal Edges: {len(edges)}")
    for edge in edges:
        print(f"Edge: {edge.get('source')} -> {edge.get('target')}")

    num_nodes = len(nodes)
    num_edges = len(edges)

    # Build graph
    graph = {}
    indegree = {}

    for node in nodes:
        graph[node["id"]] = []
        indegree[node["id"]] = 0

    for edge in edges:
        src = edge["source"]
        tgt = edge["target"]
        graph[src].append(tgt)
        indegree[tgt] += 1

    # Kahn's algorithm for DAG
    queue = [n for n in indegree if indegree[n] == 0]
    visited = 0

    while queue:
        curr = queue.pop(0)
        visited += 1
        for nei in graph[curr]:
            indegree[nei] -= 1
            if indegree[nei] == 0:
                queue.append(nei)

    is_dag = visited == num_nodes

    return {
        "num_nodes": num_nodes,
        "num_edges": num_edges,
        "is_dag": is_dag,
    }

